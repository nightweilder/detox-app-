# Detox — Phase 5

Detox is a personal Android app for reducing short-form video use and making more time to read.

## Completed phases

### Phase 1 — foundation and permission onboarding
- Kotlin, Jetpack Compose, Material 3, minSdk 26, targetSdk 35.
- Cleanly separated domain, data, permission, and presentation packages, with Hilt, Room, Preferences DataStore, and coroutines.
- Onboarding cards for Accessibility, display over other apps, Usage Access, and battery optimization exemption.

### Phase 2 — Shorts/Reels blocker
- Accessibility service checks only YouTube (`com.google.android.youtube`) and Instagram (`com.instagram.android`).
- It scans the active accessibility tree for configured view ID tokens or keyword groups. A match performs Back and shows the full-screen blocker.
- “Read a book instead” opens the Detox library (Phase 5).
- Rules are in `app/src/main/assets/blocker_rules.json` and can be edited and rebuilt when app interfaces change.

### Phase 3 — YouTube intent reminder
- When YouTube comes to the foreground, Detox shows “What are you here for?” with saved goals and today’s tasks.
- Goals persist in Preferences DataStore. Tasks are tied to the device’s local date and roll over on a new day.
- Continue leaves YouTube open; Close YouTube returns to Home.

### Phase 4 — AI emergency override
- The blocker includes an Emergency action with a short reason field (maximum 500 characters).
- The swappable `AiJudge` interface currently uses OpenAI’s Responses API with a structured verdict.
- A positive verdict grants a five-minute unlock. At most three allowed unlocks are granted per device-local day. Every submitted reason and verdict is logged in Room.
- Night hours default to 23:00–06:00 local time, can be edited, and use stricter urgency criteria.
- The API key is encrypted at rest with an AES-GCM key held by Android Keystore and is not stored in source code or Preferences DataStore. Requests are sent only after submitting a reason.

### Phase 5 — EPUB/PDF library and reader
- Choose EPUB or PDF documents through Android’s Storage Access Framework. Detox persists read access to selected document URIs; it does not copy or modify the files.
- The Room library remembers each title, document type, reading position, font size, and reader theme. Existing Phase 2–4 databases migrate from schema version 2 to 3 (and version 1 databases continue through both migrations).
- PDF pages render with Android `PdfRenderer`, with page controls and a position slider. EPUB books render their ordered text chapters with previous/next controls. Reading position is saved as the user navigates chapters/pages.
- The reader has adjustable text size and light, dark, and sepia themes. EPUB rendering is a deliberately minimal offline text reader: it strips markup and does not render the original typography, images, or complex layouts.
- The blocker’s “Read a book instead” shortcut opens the library directly. The completed home screen is deliberately quiet: a single high-contrast “Open my library” action is the visual focus. Setup, permissions, and editing remain on secondary screens.

### Review fixes after Phase 5
- Blocker: keyboard and system UI windows no longer count as "the user left the app", so the emergency form stays open while typing and the YouTube reminder does not re-fire when the notification shade or keyboard opens.
- Emergency gate: at most 8 requests per day and a 45-second wait between requests, so reworded requests cannot be tried over and over. Throttled requests are not sent to the AI or logged.
- API key store: a failed decrypt no longer deletes the saved key.
- Manifest: `allowBackup` is now false.
- Reader: PDF pages render on a white background (readable in the dark theme); stale page renders are discarded; EPUB inline tags no longer split sentences into paragraphs; named XHTML entities and one bad chapter no longer break the whole book; each chapter opens scrolled to the top; images and fonts are not loaded into memory.
- Library: book URIs are passed to the reader as Base64url (the old encode/decode could corrupt document-provider URIs); the Back button no longer leaves a blank screen when the library was opened from the blocker; PDFs reported as `application/octet-stream` are detected from the file name.

### Known gaps
- No topic-based book recommendations yet (Open Library / Gutenberg).
- No cooldown for turning the Accessibility service off.
- Detection rules in `blocker_rules.json` are untested against current YouTube/Instagram builds.
- `OpenAiCloudJudge.MODEL` is hardcoded; confirm it exists on your OpenAI account.

## Project structure

    Detox/
    ├── settings.gradle.kts
    ├── build.gradle.kts
    ├── gradle/libs.versions.toml
    ├── app/
    │   ├── build.gradle.kts
    │   └── src/main/
    │       ├── AndroidManifest.xml
    │       ├── assets/blocker_rules.json
    │       ├── java/com/example/detox/
    │       │   ├── ai/                     # Cloud AiJudge implementation
    │       │   ├── blocker/                # Detection, overlays, accessibility service
    │       │   ├── core/di/                # Hilt bindings and storage providers
    │       │   ├── data/                   # Room, DataStore, repositories
    │       │   ├── domain/                 # Models and repository/provider interfaces
    │       │   ├── presentation/            # Compose screens, settings and reader
    │       │   ├── reader/                 # Offline EPUB text extraction
    │       │   └── security/               # Android Keystore API-key encryption
    │       └── res/
    └── README.md

## Build setup

Open `outputs/Detox` in Android Studio with JDK 17 selected and install Android SDK Platform 36 (and the SDK build tools requested by Android Gradle Plugin). Sync Gradle, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The project uses Android Gradle Plugin 8.13.2. Install and update using the same application ID (`com.example.detox`) so Room’s migrations are retained.

Gradle and Android SDK tools are unavailable in this environment, so an APK build cannot be run here. Use Android Studio with JDK 17 to compile and install on a configured machine. The app needs the INTERNET permission for the optional OpenAI emergency decision.

## Manual checks

1. Install the debug APK on an Android 8.0+ device or emulator.
2. Enable Accessibility and Display over other apps in onboarding.
3. Add a goal and tasks, then reopen Detox and confirm they persist.
4. Open a configured Shorts/Reels feed, confirm the blocker appears, then choose “Read a book instead” and confirm the library opens.
5. Import one EPUB and one PDF through the system picker; confirm both appear in the library after relaunch.
6. Read EPUB chapters and move between chapters; relaunch and confirm the saved chapter is restored.
7. Read PDF pages with buttons and slider; relaunch and confirm the saved page is restored.
8. Change reader size/theme, leave the book, reopen it, and confirm those preferences remain.
9. Remove a book and confirm its library item disappears. If Android revokes the persisted document permission or the source file is removed, Detox will report that it cannot open the document.
10. Configure an OpenAI API key and night hours, then exercise allowed, denied, and night-mode emergency cases; confirm the three-unlock daily cap.

## Notes and limitations

- The cloud judge requires the user’s own OpenAI API key and an account/model with API access. No key is included in the project.
- Android Keystore encrypts the saved key at rest; a compromised/rooted device may expose it at runtime. A backend is safer for a distributed app.
- OpenAI model/API support and accessibility identifiers can change; update the model constant or blocker rules when needed.
- EPUB support is text-focused and does not preserve book styling or images. Some EPUB variants may fail parsing.
- AI approval is a convenience gate, not a substitute for emergency services or human judgment.
