package com.example.detox.domain.repository

import kotlinx.coroutines.flow.Flow

interface OnboardingRepository {
    val completed: Flow<Boolean>
    suspend fun setCompleted(completed: Boolean)
}
