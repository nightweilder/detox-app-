package com.example.detox.domain.model

data class ReminderPlan(
    val goals: List<String> = emptyList(),
    val todaysTodos: List<String> = emptyList()
)
