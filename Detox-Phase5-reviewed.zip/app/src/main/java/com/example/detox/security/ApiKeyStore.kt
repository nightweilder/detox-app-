package com.example.detox.security

interface ApiKeyStore {
    fun saveApiKey(value: String)
    fun readApiKey(): String?
    fun hasApiKey(): Boolean
    fun clearApiKey()
}
