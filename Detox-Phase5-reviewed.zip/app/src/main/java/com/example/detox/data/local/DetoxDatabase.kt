package com.example.detox.data.local

import androidx.room.Database
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.detox.data.local.dao.BookDao
import com.example.detox.data.local.dao.EmergencyJudgmentDao
import com.example.detox.data.local.entity.BookEntity
import com.example.detox.data.local.entity.EmergencyJudgmentEntity

@Entity(tableName = "phase1_marker")
data class Phase1MarkerEntity(@PrimaryKey val id: Int = 1)

@Database(entities = [Phase1MarkerEntity::class, EmergencyJudgmentEntity::class, BookEntity::class], version = 3, exportSchema = false)
abstract class DetoxDatabase : RoomDatabase() {
    abstract fun emergencyJudgmentDao(): EmergencyJudgmentDao
    abstract fun bookDao(): BookDao

    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("""CREATE TABLE IF NOT EXISTS emergency_judgments (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, requestText TEXT NOT NULL, requestedAtEpochMillis INTEGER NOT NULL, allowed INTEGER NOT NULL, reason TEXT NOT NULL, nightMode INTEGER NOT NULL, unlockUntilEpochMillis INTEGER)""")
            }
        }
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("""CREATE TABLE IF NOT EXISTS books (uri TEXT NOT NULL PRIMARY KEY, title TEXT NOT NULL, mimeType TEXT NOT NULL, progressIndex INTEGER NOT NULL, progressFraction REAL NOT NULL, fontSizeSp INTEGER NOT NULL, readerTheme TEXT NOT NULL, addedAtEpochMillis INTEGER NOT NULL)""")
            }
        }
    }
}
