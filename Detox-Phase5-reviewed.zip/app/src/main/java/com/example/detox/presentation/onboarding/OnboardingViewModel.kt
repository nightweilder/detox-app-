package com.example.detox.presentation.onboarding

import androidx.lifecycle.ViewModel
import com.example.detox.domain.model.PermissionKind
import com.example.detox.domain.repository.OnboardingRepository
import com.example.detox.permission.PermissionStatusReader
import android.content.Intent
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

data class OnboardingUiState(
    val statuses: Map<PermissionKind, Boolean> = PermissionKind.entries.associateWith { false },
    val isComplete: Boolean = false
)

@HiltViewModel
class OnboardingViewModel @Inject constructor(
    private val permissionStatusReader: PermissionStatusReader,
    private val onboardingRepository: OnboardingRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(OnboardingUiState())
    val uiState: StateFlow<OnboardingUiState> = _uiState.asStateFlow()

    init {
        refresh()
        viewModelScope.launch {
            onboardingRepository.completed.collect { completed ->
                _uiState.value = _uiState.value.copy(isComplete = completed)
            }
        }
    }

    fun refresh() {
        _uiState.value = _uiState.value.copy(
            statuses = PermissionKind.entries.associateWith(permissionStatusReader::isGranted)
        )
    }

    fun settingsIntent(kind: PermissionKind): Intent = permissionStatusReader.settingsIntent(kind)

    fun finishOnboarding() = viewModelScope.launch { onboardingRepository.setCompleted(true) }
}
