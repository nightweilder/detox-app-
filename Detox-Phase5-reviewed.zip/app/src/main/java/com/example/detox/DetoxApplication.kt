package com.example.detox

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class DetoxApplication : Application()
