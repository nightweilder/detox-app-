package com.example.detox.presentation.books

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.detox.data.local.entity.BookEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.FileNotFoundException

@Composable
fun BookLibraryScreen(nav: NavController, viewModel: BooksViewModel = hiltViewModel()) {
    val books by viewModel.books.collectAsState()
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            viewModel.import(uri, context.contentResolver.getType(uri) ?: mimeFromUri(uri))
        }
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState()).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { nav.goBackOrHome() }) { Text("Back") }
                Text("Your library", Modifier.padding(start = 12.dp), style = MaterialTheme.typography.headlineMedium)
            }
            OutlinedButton(onClick = { nav.navigate("settings") }) { Text("Settings") }
        }
        Text("Add EPUB or PDF books. Your files stay where they are; Detox remembers access to the files you choose.", Modifier.padding(vertical = 12.dp))
        Button(onClick = { picker.launch(arrayOf("application/pdf", "application/epub+zip", "application/epub")) }, modifier = Modifier.fillMaxWidth()) { Text("Add a book") }
        Spacer(Modifier.height(12.dp))
        if (books.isEmpty()) Text("Your library is empty. Choose an EPUB or PDF to begin.")
        books.forEach { book ->
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(book.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(if (book.mimeType.contains("pdf")) "PDF" else "EPUB", style = MaterialTheme.typography.bodySmall)
                    if (book.progressIndex > 0 || book.progressFraction > 0f) Text("Saved progress: ${(book.progressFraction * 100).toInt()}%")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { nav.navigate("reader/${encodeRoute(book.uri)}") }) { Text("Read") }
                        OutlinedButton(onClick = { viewModel.remove(book.uri) }) { Text("Remove") }
                    }
                }
            }
        }
    }
}

@Composable
fun BookReaderScreen(encodedUri: String, nav: NavController, viewModel: BooksViewModel = hiltViewModel()) {
    val uriString = decodeRoute(encodedUri)
    var book by remember(uriString) { mutableStateOf<BookEntity?>(null) }
    var failure by remember(uriString) { mutableStateOf<String?>(null) }
    var epubChapters by remember(uriString) { mutableStateOf<List<com.example.detox.reader.EpubReader.Chapter>>(emptyList()) }
    var chapterIndex by remember(uriString) { mutableIntStateOf(0) }
    var pdfPage by remember(uriString) { mutableIntStateOf(0) }
    var pdfPageCount by remember(uriString) { mutableIntStateOf(0) }
    var pdfBitmap by remember(uriString) { mutableStateOf<Bitmap?>(null) }
    var busy by remember(uriString) { mutableStateOf(true) }
    val context = LocalContext.current

    LaunchedEffect(uriString) {
        try {
            book = viewModel.load(uriString) ?: error("This book is no longer in your library.")
            val selected = book!!
            chapterIndex = selected.progressIndex
            pdfPage = selected.progressIndex
            if (!selected.mimeType.contains("pdf")) epubChapters = viewModel.epub(uriString)
        } catch (t: Throwable) { failure = t.message ?: "Unable to open this book." }
        finally { busy = false }
    }

    LaunchedEffect(uriString, pdfPage, book?.mimeType) {
        val selected = book ?: return@LaunchedEffect
        if (!selected.mimeType.contains("pdf")) return@LaunchedEffect
        withContext(Dispatchers.IO) {
            runCatching {
                val descriptor = context.contentResolver.openFileDescriptor(Uri.parse(uriString), "r") ?: throw FileNotFoundException()
                descriptor.use { pfd ->
                    PdfRenderer(pfd).use { renderer ->
                        pdfPageCount = renderer.pageCount
                        if (renderer.pageCount > 0) {
                            val page = renderer.openPage(pdfPage.coerceIn(0, renderer.pageCount - 1))
                            try {
                                val width = 1200
                                val bitmap = Bitmap.createBitmap(width, (width.toFloat() * page.height / page.width).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                                // PdfRenderer leaves the page background transparent; without this, black text
                                // is unreadable on the dark reader theme.
                                bitmap.eraseColor(android.graphics.Color.WHITE)
                                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                // Skip the update if the user already moved to another page while rendering.
                                if (isActive) pdfBitmap = bitmap
                            } finally {
                                page.close()
                            }
                        }
                    }
                }
            }.onFailure { failure = it.message ?: "Unable to render this PDF." }
        }
    }

    val selected = book
    val background = when (selected?.readerTheme) { "dark" -> Color(0xFF171717); "sepia" -> Color(0xFFF0E4CB); else -> MaterialTheme.colorScheme.background }
    val foreground = if (selected?.readerTheme == "dark") Color(0xFFF3F0E8) else Color(0xFF27251F)
    Column(Modifier.fillMaxSize().background(background).padding(horizontal = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 12.dp)) {
            OutlinedButton(onClick = { nav.popBackStack() }) { Text("Library") }
            Text(selected?.title ?: "Reader", Modifier.weight(1f).padding(start = 10.dp), maxLines = 1, style = MaterialTheme.typography.titleMedium, color = foreground)
        }
        if (selected != null) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Text size", color = foreground)
                OutlinedButton(onClick = { viewModel.setFont(uriString, selected.fontSizeSp - 1); book = selected.copy(fontSizeSp = (selected.fontSizeSp - 1).coerceAtLeast(12)) }) { Text("−") }
                Text("${selected.fontSizeSp} sp", color = foreground)
                OutlinedButton(onClick = { viewModel.setFont(uriString, selected.fontSizeSp + 1); book = selected.copy(fontSizeSp = (selected.fontSizeSp + 1).coerceAtMost(36)) }) { Text("+") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("light", "sepia", "dark").forEach { mode ->
                    OutlinedButton(onClick = { viewModel.setTheme(uriString, mode); book = selected.copy(readerTheme = mode) }) { Text(mode.replaceFirstChar(Char::uppercase)) }
                }
            }
        }
        when {
            busy -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            failure != null -> Text(failure.orEmpty(), color = foreground, modifier = Modifier.padding(16.dp))
            selected?.mimeType?.contains("pdf") == true -> {
                pdfBitmap?.let { Image(it.asImageBitmap(), contentDescription = "PDF page ${pdfPage + 1}", modifier = Modifier.weight(1f).fillMaxWidth()) }
                if (pdfPageCount > 0) {
                    Slider(value = pdfPage.toFloat(), onValueChange = { pdfPage = it.toInt() }, valueRange = 0f..(pdfPageCount - 1).toFloat(), modifier = Modifier.fillMaxWidth())
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { pdfPage = (pdfPage - 1).coerceAtLeast(0) }, enabled = pdfPage > 0) { Text("Previous") }
                        Text("Page ${pdfPage + 1} of $pdfPageCount", color = foreground)
                        OutlinedButton(onClick = { pdfPage = (pdfPage + 1).coerceAtMost(pdfPageCount - 1) }, enabled = pdfPage < pdfPageCount - 1) { Text("Next") }
                    }
                    LaunchedEffect(pdfPage, pdfPageCount) { if (pdfPageCount > 0) viewModel.saveProgress(uriString, pdfPage, (pdfPage + 1f) / pdfPageCount) }
                }
            }
            epubChapters.isNotEmpty() -> {
                val chapter = epubChapters[chapterIndex.coerceIn(0, epubChapters.lastIndex)]
                Text(chapter.title, color = foreground, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(vertical = 8.dp))
                // Keyed on the chapter so each new chapter starts at the top instead of the old scroll offset.
                val chapterScroll = remember(chapterIndex) { androidx.compose.foundation.ScrollState(0) }
                Text(chapter.text, color = foreground, fontSize = (selected?.fontSizeSp ?: 18).sp, lineHeight = ((selected?.fontSizeSp ?: 18) * 1.55).sp, modifier = Modifier.weight(1f).verticalScroll(chapterScroll))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { chapterIndex = (chapterIndex - 1).coerceAtLeast(0) }, enabled = chapterIndex > 0) { Text("Previous") }
                    Text("Chapter ${chapterIndex + 1} of ${epubChapters.size}", color = foreground)
                    OutlinedButton(onClick = { chapterIndex = (chapterIndex + 1).coerceAtMost(epubChapters.lastIndex) }, enabled = chapterIndex < epubChapters.lastIndex) { Text("Next") }
                }
                LaunchedEffect(chapterIndex, epubChapters.size) { if (epubChapters.isNotEmpty()) viewModel.saveProgress(uriString, chapterIndex, (chapterIndex + 1f) / epubChapters.size) }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

private fun mimeFromUri(uri: Uri): String = if (uri.toString().lowercase().endsWith("pdf")) "application/pdf" else "application/epub+zip"

// Book URIs contain '/', ':' and '%'. Base64url keeps the navigation route unambiguous, with no double decoding.
private const val ROUTE_FLAGS = android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING
private fun encodeRoute(value: String): String = android.util.Base64.encodeToString(value.toByteArray(Charsets.UTF_8), ROUTE_FLAGS)
private fun decodeRoute(value: String): String = String(android.util.Base64.decode(value, ROUTE_FLAGS), Charsets.UTF_8)

// When the library is the start destination (opened from the blocker), popBackStack() would leave a blank screen.
private fun NavController.goBackOrHome() {
    if (previousBackStackEntry != null) popBackStack()
    else navigate("home") { popUpTo("library") { inclusive = true } }
}




