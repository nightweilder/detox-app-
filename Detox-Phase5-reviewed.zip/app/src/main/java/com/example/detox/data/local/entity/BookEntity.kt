package com.example.detox.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "books")
data class BookEntity(
    @PrimaryKey val uri: String,
    val title: String,
    val mimeType: String,
    val progressIndex: Int = 0,
    val progressFraction: Float = 0f,
    val fontSizeSp: Int = 18,
    val readerTheme: String = "light",
    val addedAtEpochMillis: Long = System.currentTimeMillis()
)
