package com.example.detox.data.settings

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.example.detox.domain.settings.EmergencySettingsRepository
import com.example.detox.domain.settings.NightWindow
import java.time.LocalTime
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class EmergencySettingsRepositoryImpl @Inject constructor(
    private val dataStore: DataStore<Preferences>
) : EmergencySettingsRepository {
    private val startKey = stringPreferencesKey("night_mode_start")
    private val endKey = stringPreferencesKey("night_mode_end")

    override val nightWindow: Flow<NightWindow> = dataStore.data.map { preferences ->
        val start = preferences[startKey]?.let { value -> runCatching { LocalTime.parse(value) }.getOrNull() }
            ?: NightWindow().start
        val end = preferences[endKey]?.let { value -> runCatching { LocalTime.parse(value) }.getOrNull() }
            ?: NightWindow().end
        NightWindow(start, end)
    }

    override suspend fun updateNightWindow(start: LocalTime, end: LocalTime) {
        dataStore.edit { preferences ->
            preferences[startKey] = start.toString()
            preferences[endKey] = end.toString()
        }
    }
}
