package com.example.detox.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.detox.data.local.entity.EmergencyJudgmentEntity

@Dao
interface EmergencyJudgmentDao {
    @Insert
    suspend fun insert(judgment: EmergencyJudgmentEntity)

    @Query("""
        SELECT COUNT(*) FROM emergency_judgments
        WHERE allowed = 1
          AND requestedAtEpochMillis >= :dayStart
          AND requestedAtEpochMillis < :nextDay
    """)
    suspend fun countAllowedUnlocks(dayStart: Long, nextDay: Long): Int

    @Query("""
        SELECT COUNT(*) FROM emergency_judgments
        WHERE requestedAtEpochMillis >= :dayStart
          AND requestedAtEpochMillis < :nextDay
    """)
    suspend fun countAttempts(dayStart: Long, nextDay: Long): Int

    @Query("SELECT MAX(requestedAtEpochMillis) FROM emergency_judgments")
    suspend fun latestRequestAt(): Long?

    @Query("""
        SELECT MAX(unlockUntilEpochMillis) FROM emergency_judgments
        WHERE allowed = 1 AND unlockUntilEpochMillis > :nowEpochMillis
    """)
    suspend fun activeUnlockUntil(nowEpochMillis: Long): Long?
}
