package com.example.detox.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val colors = lightColorScheme(
    primary = Color(0xFF355C4B),
    onPrimary = Color.White,
    background = Color(0xFFF7F6F1),
    surface = Color.White,
    secondary = Color(0xFF8B6F47)
)

@Composable
fun DetoxTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = colors, content = content)
}
