package com.example.detox.domain.settings

import java.time.LocalTime

data class NightWindow(
    val start: LocalTime = LocalTime.of(23, 0),
    val end: LocalTime = LocalTime.of(6, 0)
) {
    fun isActive(at: LocalTime = LocalTime.now()): Boolean =
        when {
            start == end -> false
            start < end -> !at.isBefore(start) && at.isBefore(end)
            else -> !at.isBefore(start) || at.isBefore(end)
        }
}

interface EmergencySettingsRepository {
    val nightWindow: kotlinx.coroutines.flow.Flow<NightWindow>
    suspend fun updateNightWindow(start: LocalTime, end: LocalTime)
}
