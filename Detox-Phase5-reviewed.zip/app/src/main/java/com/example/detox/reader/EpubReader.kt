package com.example.detox.reader

import android.content.ContentResolver
import android.net.Uri
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.util.zip.ZipInputStream

/** Minimal, offline EPUB text extractor. It follows the package spine and strips markup. */
object EpubReader {
    data class Chapter(val title: String, val text: String)

    fun read(resolver: ContentResolver, uri: Uri): List<Chapter> {
        val files = linkedMapOf<String, ByteArray>()
        resolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    // Keep only markup/package files; skipping images and fonts avoids loading the whole book into memory.
                    if (!entry.isDirectory && entry.name.substringAfterLast('.', "").lowercase() in TEXT_EXTENSIONS) {
                        files[entry.name] = zip.readBytes()
                    }
                    zip.closeEntry()
                }
            }
        } ?: error("Unable to open EPUB")

        val container = files["META-INF/container.xml"]?.decodeToString() ?: error("EPUB container is missing")
        val opfPath = Regex("rootfile[^>]*full-path=[\"']([^\"']+)").find(container)?.groupValues?.get(1)
            ?: error("EPUB package document is missing")
        val opf = files[opfPath]?.decodeToString() ?: error("EPUB package document cannot be read")
        val base = opfPath.substringBeforeLast('/', "")
        val manifest = Regex("<item\\b([^>]+?)/?>", RegexOption.IGNORE_CASE).findAll(opf).associate { match ->
            val attrs = match.groupValues[1]
            val id = Regex("\\bid=[\"']([^\"']+)").find(attrs)?.groupValues?.get(1).orEmpty()
            val href = Regex("\\bhref=[\"']([^\"']+)").find(attrs)?.groupValues?.get(1).orEmpty()
            id to resolve(base, href)
        }
        val spine = Regex("<itemref\\b[^>]*\\bidref=[\"']([^\"']+)").findAll(opf).mapNotNull { manifest[it.groupValues[1]] }.toList()
        if (spine.isEmpty()) error("EPUB has no readable chapters")
        return spine.mapIndexedNotNull { index, path ->
            val markup = files[path]?.decodeToString() ?: return@mapIndexedNotNull null
            val title = Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                .find(markup)?.groupValues?.get(1)?.let(::decodeEntities)?.trim().orEmpty().ifBlank { "Chapter ${index + 1}" }
            // One malformed chapter should not make the whole book unreadable.
            val text = runCatching { extractText(markup) }.getOrDefault("")
            if (text.isBlank()) null else Chapter(title, text)
        }.ifEmpty { error("EPUB contains no readable text") }
    }

    private fun extractText(rawMarkup: String): String {
        // XHTML often uses named entities (&nbsp;, &mdash;) that the strict parser rejects; use numeric references.
        val markup = NAMED_ENTITY.replace(rawMarkup) { match ->
            NAMED_ENTITIES[match.groupValues[1]]?.let { "&#$it;" } ?: match.value
        }
        val parser = Xml.newPullParser()
        runCatching { parser.setFeature(XmlPullParser.FEATURE_RELAXED, true) }
        parser.setInput(markup.reader())
        val result = StringBuilder()
        val paragraph = StringBuilder()
        // Inline tags (<em>, <a>, <span>) must stay inside one paragraph; only block tags start a new one.
        fun flush() {
            val text = paragraph.toString().replace(WHITESPACE, " ").trim()
            if (text.isNotEmpty()) result.append(text).append("\n\n")
            paragraph.setLength(0)
        }
        var event = parser.eventType
        var skipDepth = 0
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    val name = parser.name.lowercase()
                    if (name in SKIPPED_TAGS) skipDepth++ else if (name in BLOCK_TAGS) flush()
                }
                XmlPullParser.END_TAG -> {
                    val name = parser.name.lowercase()
                    if (name in SKIPPED_TAGS) { if (skipDepth > 0) skipDepth-- } else if (name in BLOCK_TAGS) flush()
                }
                XmlPullParser.TEXT -> if (skipDepth == 0) paragraph.append(parser.text)
            }
            event = parser.next()
        }
        flush()
        return result.toString().trim()
    }

    private val TEXT_EXTENSIONS = setOf("xhtml", "html", "htm", "xml", "opf")
    private val SKIPPED_TAGS = setOf("script", "style", "head")
    private val BLOCK_TAGS = setOf(
        "p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "br", "tr",
        "blockquote", "section", "article", "pre", "ul", "ol", "table"
    )
    private val WHITESPACE = Regex("\\s+")
    private val NAMED_ENTITY = Regex("&([A-Za-z][A-Za-z0-9]*);")
    private val NAMED_ENTITIES = mapOf(
        "nbsp" to 160, "mdash" to 8212, "ndash" to 8211, "hellip" to 8230,
        "lsquo" to 8216, "rsquo" to 8217, "ldquo" to 8220, "rdquo" to 8221,
        "copy" to 169, "eacute" to 233, "egrave" to 232, "agrave" to 224,
        "uuml" to 252, "ouml" to 246, "auml" to 228, "ccedil" to 231
    )

    private fun resolve(base: String, href: String): String {
        val parts = (if (base.isBlank()) href else "$base/$href").split('/')
        val stack = mutableListOf<String>()
        parts.forEach { when (it) { "", "." -> Unit; ".." -> if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex); else -> stack += it } }
        return stack.joinToString("/")
    }

    private fun decodeEntities(value: String): String = value
        .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        .replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")
}
