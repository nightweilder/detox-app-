package com.example.detox.core.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStoreFile
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.room.Room
import com.example.detox.data.local.DetoxDatabase
import com.example.detox.data.local.dao.BookDao
import com.example.detox.data.repository.OnboardingRepositoryImpl
import com.example.detox.data.repository.ReminderPlanRepositoryImpl
import com.example.detox.data.settings.EmergencySettingsRepositoryImpl
import com.example.detox.data.emergency.EmergencyOverrideCoordinatorImpl
import com.example.detox.ai.OpenAiCloudJudge
import com.example.detox.security.AndroidKeystoreApiKeyStore
import com.example.detox.domain.repository.OnboardingRepository
import com.example.detox.domain.repository.ReminderPlanRepository
import com.example.detox.domain.settings.EmergencySettingsRepository
import com.example.detox.domain.emergency.EmergencyOverrideCoordinator
import com.example.detox.domain.ai.AiJudge
import com.example.detox.security.ApiKeyStore
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds @Singleton
    abstract fun bindOnboardingRepository(impl: OnboardingRepositoryImpl): OnboardingRepository

    @Binds @Singleton
    abstract fun bindReminderPlanRepository(impl: ReminderPlanRepositoryImpl): ReminderPlanRepository

    @Binds @Singleton
    abstract fun bindEmergencySettingsRepository(impl: EmergencySettingsRepositoryImpl): EmergencySettingsRepository

    @Binds @Singleton
    abstract fun bindApiKeyStore(impl: AndroidKeystoreApiKeyStore): ApiKeyStore

    @Binds @Singleton
    abstract fun bindAiJudge(impl: OpenAiCloudJudge): AiJudge

    @Binds @Singleton
    abstract fun bindEmergencyOverrideCoordinator(impl: EmergencyOverrideCoordinatorImpl): EmergencyOverrideCoordinator
}

@Module
@InstallIn(SingletonComponent::class)
object StorageModule {
    @Provides @Singleton
    fun provideDataStore(@ApplicationContext context: Context): DataStore<Preferences> =
        PreferenceDataStoreFactory.create { context.preferencesDataStoreFile("detox_preferences") }

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext context: Context): DetoxDatabase =
        Room.databaseBuilder(context, DetoxDatabase::class.java, "detox.db")
            .addMigrations(DetoxDatabase.MIGRATION_1_2, DetoxDatabase.MIGRATION_2_3)
            .build()

    @Provides
    fun provideBookDao(database: DetoxDatabase): BookDao = database.bookDao()
}








