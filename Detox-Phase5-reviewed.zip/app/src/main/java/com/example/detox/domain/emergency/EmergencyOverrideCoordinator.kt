package com.example.detox.domain.emergency

data class EmergencyAttempt(
    val allow: Boolean,
    val reason: String,
    val unlockUntilEpochMillis: Long? = null
)

interface EmergencyOverrideCoordinator {
    suspend fun evaluate(request: String): EmergencyAttempt
    suspend fun activeUnlockUntil(nowEpochMillis: Long): Long?
}
