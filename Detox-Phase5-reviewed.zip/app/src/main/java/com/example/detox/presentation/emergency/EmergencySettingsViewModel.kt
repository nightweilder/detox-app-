package com.example.detox.presentation.emergency

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.detox.domain.settings.EmergencySettingsRepository
import com.example.detox.domain.settings.NightWindow
import com.example.detox.security.ApiKeyStore
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalTime
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

data class EmergencySettingsUiState(
    val nightWindow: NightWindow = NightWindow(),
    val apiKeyAvailable: Boolean = false,
    val message: String? = null
)

@HiltViewModel
class EmergencySettingsViewModel @Inject constructor(
    private val settingsRepository: EmergencySettingsRepository,
    private val apiKeyStore: ApiKeyStore
) : ViewModel() {
    private val _state = MutableStateFlow(EmergencySettingsUiState())
    val state: StateFlow<EmergencySettingsUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            settingsRepository.nightWindow.collect { window ->
                _state.value = _state.value.copy(nightWindow = window)
            }
        }
        refreshApiKeyStatus()
    }

    fun refreshApiKeyStatus() {
        viewModelScope.launch(Dispatchers.IO) {
            _state.value = _state.value.copy(apiKeyAvailable = apiKeyStore.hasApiKey())
        }
    }

    fun saveApiKey(value: String) {
        if (value.isBlank()) {
            _state.value = _state.value.copy(message = "Enter an API key first.")
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            val result = runCatching { apiKeyStore.saveApiKey(value) }
            _state.value = if (result.isSuccess) {
                _state.value.copy(apiKeyAvailable = true, message = "API key saved securely on this device.")
            } else {
                _state.value.copy(apiKeyAvailable = false, message = "The API key could not be saved.")
            }
        }
    }

    fun clearApiKey() {
        viewModelScope.launch(Dispatchers.IO) {
            val result = runCatching { apiKeyStore.clearApiKey() }
            _state.value = _state.value.copy(
                apiKeyAvailable = false,
                message = if (result.isSuccess) "API key removed." else "The API key could not be removed."
            )
        }
    }

    fun saveNightWindow(startText: String, endText: String) {
        val start = runCatching { LocalTime.parse(startText.trim()) }.getOrNull()
        val end = runCatching { LocalTime.parse(endText.trim()) }.getOrNull()
        if (start == null || end == null || start == end) {
            _state.value = _state.value.copy(message = "Enter different 24-hour times in HH:mm format.")
            return
        }
        viewModelScope.launch {
            runCatching { settingsRepository.updateNightWindow(start, end) }
                .onSuccess { _state.value = _state.value.copy(message = "Night hours saved.") }
                .onFailure { _state.value = _state.value.copy(message = "Night hours could not be saved.") }
        }
    }
}
