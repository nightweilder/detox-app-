package com.example.detox.blocker

class ShortFormDetector(private val rules: List<ShortFormRule>) {
    fun matches(packageName: String, observedViewIds: List<String>, observedText: String): Boolean {
        val text = observedText.lowercase()
        return rules.asSequence()
            .filter { it.packageName == packageName }
            .any { rule ->
                val viewIdMatch = rule.viewIdTokens.any { token ->
                    observedViewIds.any { id -> id.lowercase().contains(token) }
                }
                val textMatch = rule.textGroupsAnyOf.any { group ->
                    group.isNotEmpty() && group.all(text::contains)
                }
                viewIdMatch || textMatch
            }
    }
}
