package com.example.detox.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.detox.data.local.entity.BookEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BookDao {
    @Query("SELECT * FROM books ORDER BY addedAtEpochMillis DESC") fun observeBooks(): Flow<List<BookEntity>>
    @Query("SELECT * FROM books WHERE uri = :uri LIMIT 1") suspend fun get(uri: String): BookEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun put(book: BookEntity)
    @Query("UPDATE books SET progressIndex = :index, progressFraction = :fraction WHERE uri = :uri")
    suspend fun updateProgress(uri: String, index: Int, fraction: Float)
    @Query("UPDATE books SET fontSizeSp = :size WHERE uri = :uri") suspend fun updateFontSize(uri: String, size: Int)
    @Query("UPDATE books SET readerTheme = :theme WHERE uri = :uri") suspend fun updateTheme(uri: String, theme: String)
    @Query("DELETE FROM books WHERE uri = :uri") suspend fun delete(uri: String)
}
