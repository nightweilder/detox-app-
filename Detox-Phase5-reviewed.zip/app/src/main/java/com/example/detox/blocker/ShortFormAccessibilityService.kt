package com.example.detox.blocker

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat
import com.example.detox.R
import com.example.detox.MainActivity
import com.example.detox.domain.model.ReminderPlan
import com.example.detox.domain.emergency.EmergencyAttempt
import com.example.detox.domain.emergency.EmergencyOverrideCoordinator
import com.example.detox.domain.repository.ReminderPlanRepository
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@AndroidEntryPoint
class ShortFormAccessibilityService : AccessibilityService() {
    @Inject lateinit var blockerConfigRepository: BlockerConfigRepository
    @Inject lateinit var reminderPlanRepository: ReminderPlanRepository
    @Inject lateinit var emergencyOverrideCoordinator: EmergencyOverrideCoordinator

    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var detector = ShortFormDetector(emptyList())
    private var overlayView: View? = null
    private var lastForegroundPackage: String? = null
    private var lastBlockTime = 0L
    private var lastScanTime = 0L
    private var pendingReminder: Runnable? = null
    private var activeUnlockUntil = 0L
    private var checkingUnlock = false
    private var blockedPackage = YOUTUBE_PACKAGE
    private var imePackages: Set<String> = emptySet()
    private var imePackagesLoadedAt = Long.MIN_VALUE / 2

    override fun onServiceConnected() {
        super.onServiceConnected()
        detector = ShortFormDetector(blockerConfigRepository.loadRules())
        ioScope.launch {
            val unlock = runCatching {
                emergencyOverrideCoordinator.activeUnlockUntil(System.currentTimeMillis())
            }.getOrNull() ?: 0L
            mainHandler.post { activeUnlockUntil = unlock }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val currentPackage = event.packageName?.toString() ?: return
        if (currentPackage == packageName) return
        // Keyboard and system UI windows (notification shade, heads-up) fire events too.
        // Treating them as "user left the app" would close the emergency form as soon as
        // the keyboard opens and would re-trigger the YouTube reminder.
        if (isTransientPackage(currentPackage)) return

        val isTargetPackage = currentPackage == YOUTUBE_PACKAGE || currentPackage == INSTAGRAM_PACKAGE
        if (overlayView != null) {
            if (!isTargetPackage) {
                removeOverlay()
                if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                    lastForegroundPackage = currentPackage
                }
            }
            return
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val enteringYoutube = currentPackage == YOUTUBE_PACKAGE && lastForegroundPackage != YOUTUBE_PACKAGE
            lastForegroundPackage = currentPackage
            if (enteringYoutube && Settings.canDrawOverlays(this)) scheduleYoutubeReminder()
        }

        if (!isTargetPackage || !Settings.canDrawOverlays(this)) return
        if (event.eventType !in RELEVANT_EVENTS) return

        val scanNow = android.os.SystemClock.uptimeMillis()
        if (scanNow - lastScanTime < MIN_SCAN_INTERVAL_MS) return
        lastScanTime = scanNow

        if (isShortFormActive(currentPackage)) checkUnlockThenBlock(currentPackage)
    }

    private fun isTransientPackage(pkg: String): Boolean {
        if (pkg == SYSTEM_UI_PACKAGE) return true
        val now = android.os.SystemClock.uptimeMillis()
        if (now - imePackagesLoadedAt > IME_CACHE_MS) {
            imePackagesLoadedAt = now
            imePackages = runCatching {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .enabledInputMethodList.map { it.packageName }.toSet()
            }.getOrDefault(imePackages)
        }
        return pkg in imePackages
    }

    private fun isShortFormActive(currentPackage: String): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() != currentPackage) return false
        val observedIds = ArrayList<String>()
        val observedText = StringBuilder()
        collectSignals(root, observedIds, observedText)
        return detector.matches(currentPackage, observedIds, observedText.toString())
    }

    private fun collectSignals(root: AccessibilityNodeInfo, ids: MutableList<String>, text: StringBuilder) {
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        while (stack.isNotEmpty() && visited < MAX_NODES) {
            val node = stack.removeLast()
            visited++
            node.viewIdResourceName?.let(ids::add)
            node.text?.toString()?.let { if (it.isNotBlank()) text.append(' ').append(it) }
            node.contentDescription?.toString()?.let { if (it.isNotBlank()) text.append(' ').append(it) }
            for (index in 0 until node.childCount) {
                node.getChild(index)?.let(stack::add)
            }
        }
    }

    private fun checkUnlockThenBlock(currentPackage: String) {
        if (System.currentTimeMillis() < activeUnlockUntil || checkingUnlock) return
        checkingUnlock = true
        ioScope.launch {
            val unlock = runCatching {
                emergencyOverrideCoordinator.activeUnlockUntil(System.currentTimeMillis())
            }.getOrNull() ?: 0L
            mainHandler.post {
                checkingUnlock = false
                activeUnlockUntil = unlock
                if (System.currentTimeMillis() >= activeUnlockUntil && overlayView == null && isShortFormActive(currentPackage)) {
                    blockShortForm(currentPackage)
                }
            }
        }
    }

    private fun blockShortForm(targetPackage: String) {
        val now = System.currentTimeMillis()
        if (now - lastBlockTime < BLOCK_COOLDOWN_MS) return
        lastBlockTime = now
        blockedPackage = targetPackage
        cancelPendingReminder()
        performGlobalAction(GLOBAL_ACTION_BACK)
        mainHandler.postDelayed({ showBlockOverlay() }, BACK_DELAY_MS)
    }

    private fun scheduleYoutubeReminder() {
        cancelPendingReminder()
        val task = Runnable {
            ioScope.launch {
                val plan = runCatching { reminderPlanRepository.plan.first() }.getOrDefault(ReminderPlan())
                mainHandler.post {
                    if (lastForegroundPackage == YOUTUBE_PACKAGE && overlayView == null) {
                        showYoutubeReminderOverlay(plan)
                    }
                }
            }
        }
        pendingReminder = task
        mainHandler.postDelayed(task, REMINDER_DELAY_MS)
    }

    private fun cancelPendingReminder() {
        pendingReminder?.let(mainHandler::removeCallbacks)
        pendingReminder = null
    }

    private fun showBlockOverlay() {
        if (overlayView != null || !Settings.canDrawOverlays(this)) return
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(40), dp(32), dp(40))
        }
        val title = textView(getString(R.string.blocker_title), 30f, bold = true)
        val message = textView(getString(R.string.blocker_message), 17f).apply {
            setPadding(0, dp(16), 0, dp(28))
        }
        val readButton = Button(this).apply {
            text = getString(R.string.blocker_read_button)
            setOnClickListener {
                removeOverlay()
                val intent = Intent(this@ShortFormAccessibilityService, MainActivity::class.java).apply {
                    putExtra(MainActivity.EXTRA_OPEN_LIBRARY, true)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(intent)
            }
        }
        content.addView(title, matchWrap())
        content.addView(message, matchWrap())
        content.addView(readButton, matchWrap())
        val emergencyButton = Button(this).apply {
            text = getString(R.string.emergency_button)
            setOnClickListener { showEmergencyRequestOverlay() }
        }
        content.addView(emergencyButton, matchWrap())
        val background = FrameLayout(this).apply {
            setBackgroundColor(ContextCompat.getColor(this@ShortFormAccessibilityService, R.color.blocker_background))
            isClickable = true
            isFocusable = true
            addView(content, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }
        addOverlay(background)
    }

    private fun showYoutubeReminderOverlay(plan: ReminderPlan) {
        if (overlayView != null || !Settings.canDrawOverlays(this)) return

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(24), dp(24), dp(16))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(24).toFloat()
            }
            isClickable = true
        }
        card.addView(textView(getString(R.string.youtube_reminder_title), 25f, bold = true), matchWrap())

        val scrollContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, dp(12))
        }
        scrollContent.addView(textView(getString(R.string.youtube_reminder_goals), 16f, bold = true), matchWrap())
        addPlanItems(scrollContent, plan.goals, R.string.youtube_reminder_no_goals)
        val divider = View(this).apply { setBackgroundColor(0xFFE7E5DF.toInt()) }
        scrollContent.addView(divider, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply {
            topMargin = dp(12)
            bottomMargin = dp(12)
        })
        scrollContent.addView(textView(getString(R.string.youtube_reminder_todos), 16f, bold = true), matchWrap())
        addPlanItems(scrollContent, plan.todaysTodos, R.string.youtube_reminder_no_todos)

        val scroll = ScrollView(this).apply {
            isFillViewport = false
            addView(scrollContent)
        }
        card.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(300)))

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val continueButton = Button(this).apply {
            text = getString(R.string.youtube_reminder_continue)
            setOnClickListener {
                removeOverlay()
                mainHandler.postDelayed({
                    if (lastForegroundPackage == YOUTUBE_PACKAGE && isShortFormActive(YOUTUBE_PACKAGE)) {
                        checkUnlockThenBlock(YOUTUBE_PACKAGE)
                    }
                }, RECHECK_DELAY_MS)
            }
        }
        val closeButton = Button(this).apply {
            text = getString(R.string.youtube_reminder_close)
            setOnClickListener {
                removeOverlay()
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
        }
        buttons.addView(continueButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        buttons.addView(closeButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(buttons, matchWrap())

        val scrim = FrameLayout(this).apply {
            setBackgroundColor(0xB3000000.toInt())
            isClickable = true
            isFocusable = true
            val cardParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            ).apply {
                leftMargin = dp(20)
                rightMargin = dp(20)
                topMargin = dp(24)
                bottomMargin = dp(24)
            }
            addView(card, cardParams)
        }
        addOverlay(scrim)
    }

    private fun showEmergencyRequestOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        removeOverlay()

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(24), dp(24), dp(20))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(24).toFloat()
            }
            isFocusableInTouchMode = true
        }
        card.addView(textView(getString(R.string.emergency_title), 24f, bold = true), matchWrap())
        card.addView(textView(getString(R.string.emergency_explanation), 15f).apply {
            setPadding(0, dp(10), 0, dp(12))
        }, matchWrap())

        val input = EditText(this).apply {
            hint = getString(R.string.emergency_reason_hint)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            minLines = 3
            maxLines = 5
            gravity = Gravity.TOP or Gravity.START
            filters = arrayOf(InputFilter.LengthFilter(MAX_EMERGENCY_INPUT))
        }
        card.addView(input, matchWrap())

        val status = textView("", 14f).apply {
            visibility = View.GONE
            setPadding(0, dp(12), 0, dp(8))
        }
        card.addView(status, matchWrap())

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val submit = Button(this).apply {
            text = getString(R.string.emergency_submit)
        }
        val cancel = Button(this).apply {
            text = getString(R.string.emergency_cancel)
            setOnClickListener {
                removeOverlay()
                showBlockOverlay()
            }
        }
        buttons.addView(submit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        buttons.addView(cancel, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(buttons, matchWrap())

        val form = FrameLayout(this).apply {
            setBackgroundColor(0xB3000000.toInt())
            isClickable = true
            isFocusable = true
            addView(
                card,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                ).apply {
                    leftMargin = dp(20)
                    rightMargin = dp(20)
                    topMargin = dp(24)
                    bottomMargin = dp(24)
                }
            )
        }

        submit.setOnClickListener {
            val request = input.text?.toString()?.trim().orEmpty()
            if (request.isBlank()) {
                status.text = getString(R.string.emergency_empty_reason)
                status.visibility = View.VISIBLE
                return@setOnClickListener
            }
            submit.isEnabled = false
            cancel.isEnabled = false
            status.text = getString(R.string.emergency_checking)
            status.visibility = View.VISIBLE

            ioScope.launch {
                val attempt = runCatching { emergencyOverrideCoordinator.evaluate(request) }
                    .getOrElse { EmergencyAttempt(false, getString(R.string.emergency_log_error)) }
                mainHandler.post {
                    if (overlayView !== form) return@post
                    status.text = getString(
                        if (attempt.allow) R.string.emergency_allowed_reason else R.string.emergency_denied_reason,
                        attempt.reason
                    )
                    submit.isEnabled = true
                    cancel.isEnabled = true
                    submit.text = getString(
                        if (attempt.allow) R.string.emergency_continue else R.string.emergency_back_to_blocker
                    )
                    cancel.text = getString(R.string.emergency_cancel)
                    submit.setOnClickListener {
                        if (attempt.allow) {
                            activeUnlockUntil = attempt.unlockUntilEpochMillis ?: 0L
                            continueBlockedApp()
                        } else {
                            removeOverlay()
                            showBlockOverlay()
                        }
                    }
                }
            }
        }

        addOverlay(form)
        input.requestFocus()
        mainHandler.postDelayed({
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }, KEYBOARD_DELAY_MS)
    }

    private fun continueBlockedApp() {
        val target = blockedPackage
        removeOverlay()
        val launchIntent = packageManager.getLaunchIntentForPackage(target)
        if (launchIntent == null) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            return
        }
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        runCatching { startActivity(launchIntent) }
            .onFailure { performGlobalAction(GLOBAL_ACTION_BACK) }
    }
    private fun addPlanItems(container: LinearLayout, values: List<String>, emptyMessage: Int) {
        val visibleValues = values.take(MAX_REMINDER_ITEMS)
        if (visibleValues.isEmpty()) {
            container.addView(textView(getString(emptyMessage), 14f), matchWrap())
        } else {
            visibleValues.forEach { value ->
                container.addView(textView("• $value", 15f).apply {
                    setPadding(0, dp(5), 0, dp(5))
                }, matchWrap())
            }
            if (values.size > MAX_REMINDER_ITEMS) {
                container.addView(textView(getString(R.string.youtube_reminder_more_items), 13f), matchWrap())
            }
        }
    }

    private fun textView(value: String, size: Float, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            gravity = Gravity.CENTER
            setTextColor(ContextCompat.getColor(this@ShortFormAccessibilityService, R.color.blocker_text))
            if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun addOverlay(view: View) {
        val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val layout = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        try {
            windowManager.addView(view, layout)
            overlayView = view
        } catch (error: SecurityException) {
            Log.e(TAG, "Overlay permission was revoked", error)
        } catch (error: WindowManager.BadTokenException) {
            Log.e(TAG, "Could not display overlay", error)
        }
    }

    private fun removeOverlay() {
        val view = overlayView ?: return
        overlayView = null
        runCatching { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(view) }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        cancelPendingReminder()
        ioScope.cancel()
        removeOverlay()
        mainHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private companion object {
        const val TAG = "DetoxShortFormBlocker"
        const val YOUTUBE_PACKAGE = "com.google.android.youtube"
        const val INSTAGRAM_PACKAGE = "com.instagram.android"
        const val SYSTEM_UI_PACKAGE = "com.android.systemui"
        const val IME_CACHE_MS = 60_000L
        const val MAX_NODES = 600
        const val MAX_REMINDER_ITEMS = 8
        const val MAX_EMERGENCY_INPUT = 500
        const val BACK_DELAY_MS = 180L
        const val REMINDER_DELAY_MS = 450L
        const val RECHECK_DELAY_MS = 150L
        const val KEYBOARD_DELAY_MS = 180L
        const val BLOCK_COOLDOWN_MS = 3_000L
        const val MIN_SCAN_INTERVAL_MS = 180L
        val RELEVANT_EVENTS = setOf(
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED
        )
    }
}







