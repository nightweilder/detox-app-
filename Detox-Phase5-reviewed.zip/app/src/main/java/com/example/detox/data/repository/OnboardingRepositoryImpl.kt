package com.example.detox.data.repository

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.booleanPreferencesKey
import com.example.detox.domain.repository.OnboardingRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class OnboardingRepositoryImpl @Inject constructor(
    private val dataStore: DataStore<Preferences>
) : OnboardingRepository {
    private val completedKey = booleanPreferencesKey("onboarding_completed")
    override val completed: Flow<Boolean> = dataStore.data.map { it[completedKey] ?: false }
    override suspend fun setCompleted(completed: Boolean) {
        dataStore.edit { it[completedKey] = completed }
    }
}
