package com.example.detox.data.emergency

import com.example.detox.data.local.DetoxDatabase
import com.example.detox.data.local.entity.EmergencyJudgmentEntity
import com.example.detox.domain.ai.AiJudge
import com.example.detox.domain.ai.AiVerdict
import com.example.detox.domain.emergency.EmergencyAttempt
import com.example.detox.domain.emergency.EmergencyOverrideCoordinator
import com.example.detox.domain.settings.EmergencySettingsRepository
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

@Singleton
class EmergencyOverrideCoordinatorImpl @Inject constructor(
    database: DetoxDatabase,
    private val aiJudge: AiJudge,
    private val settingsRepository: EmergencySettingsRepository
) : EmergencyOverrideCoordinator {
    private val judgments = database.emergencyJudgmentDao()
    private val requestMutex = Mutex()

    override suspend fun evaluate(request: String): EmergencyAttempt = requestMutex.withLock {
        val safeRequest = request.trim().take(MAX_REQUEST_LENGTH)
        val requestedAt = System.currentTimeMillis()
        val nightMode = settingsRepository.nightWindow.first().isActive(LocalTime.now())
        val (dayStart, nextDay) = localDayBounds()
        val allowedToday = judgments.countAllowedUnlocks(dayStart, nextDay)

        // Throttle repeated asking so the AI gate cannot be brute-forced with reworded requests.
        // Throttled attempts are not sent to the AI and are not logged.
        if (safeRequest.isNotBlank()) {
            val attemptsToday = judgments.countAttempts(dayStart, nextDay)
            val sinceLast = requestedAt - (judgments.latestRequestAt() ?: 0L)
            if (attemptsToday >= MAX_DAILY_ATTEMPTS) {
                return@withLock EmergencyAttempt(false, "Too many emergency requests today. Try again tomorrow.", null)
            }
            if (sinceLast in 0 until RETRY_COOLDOWN_MS) {
                val wait = ((RETRY_COOLDOWN_MS - sinceLast) / 1_000L) + 1
                return@withLock EmergencyAttempt(false, "Wait $wait seconds before asking again.", null)
            }
        }

        val verdict = when {
            safeRequest.isBlank() -> AiVerdict(false, "Enter a short reason for this request.")
            allowedToday >= MAX_DAILY_UNLOCKS -> AiVerdict(false, "You have used all three emergency unlocks for today.")
            else -> judgeSafely(safeRequest, nightMode)
        }

        val granted = verdict.allow && verdict.reason.isNotBlank() && allowedToday < MAX_DAILY_UNLOCKS
        val unlockUntil = if (granted) System.currentTimeMillis() + UNLOCK_DURATION_MS else null
        val reason = verdict.reason.ifBlank { "The request was denied." }.take(MAX_REASON_LENGTH)

        judgments.insert(
            EmergencyJudgmentEntity(
                requestText = safeRequest,
                requestedAtEpochMillis = requestedAt,
                allowed = granted,
                reason = reason,
                nightMode = nightMode,
                unlockUntilEpochMillis = unlockUntil
            )
        )
        EmergencyAttempt(granted, reason, unlockUntil)
    }

    private suspend fun judgeSafely(request: String, nightMode: Boolean): AiVerdict = try {
        aiJudge.judge(request, nightMode)
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (error: Exception) {
        val missingKey = error.message?.contains("API key", ignoreCase = true) == true
        AiVerdict(
            allow = false,
            reason = if (missingKey) {
                "Add your OpenAI API key in Detox settings. This request was denied."
            } else {
                "The AI service could not be reached. Check the key or connection. This request was denied."
            }
        )
    }

    override suspend fun activeUnlockUntil(nowEpochMillis: Long): Long? =
        judgments.activeUnlockUntil(nowEpochMillis)

    private fun localDayBounds(): Pair<Long, Long> {
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        val start = today.atStartOfDay(zone).toInstant().toEpochMilli()
        val nextDay = today.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        return start to nextDay
    }

    private companion object {
        const val MAX_REQUEST_LENGTH = 500
        const val MAX_REASON_LENGTH = 240
        const val MAX_DAILY_UNLOCKS = 3
        const val MAX_DAILY_ATTEMPTS = 8
        const val RETRY_COOLDOWN_MS = 45_000L
        const val UNLOCK_DURATION_MS = 5 * 60 * 1_000L
    }
}
