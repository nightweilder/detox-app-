package com.example.detox.blocker

import android.content.Context
import android.util.Log
import dagger.hilt.android.qualifiers.ApplicationContext
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BlockerConfigRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    fun loadRules(): List<ShortFormRule> = try {
        context.assets.open(CONFIG_FILE).bufferedReader().use { reader ->
            val entries = JSONObject(reader.readText()).getJSONArray("rules")
            buildList {
                for (index in 0 until entries.length()) {
                    val rule = entries.getJSONObject(index)
                    val groups = rule.optJSONArray("textGroupsAnyOf") ?: JSONArray()
                    add(
                        ShortFormRule(
                            packageName = rule.getString("packageName"),
                            viewIdTokens = rule.stringList("viewIdTokens"),
                            textGroupsAnyOf = List(groups.length()) { groupIndex ->
                                groups.getJSONArray(groupIndex).asStringList()
                            }
                        )
                    )
                }
            }
        }
    } catch (error: Exception) {
        Log.e(TAG, "Could not load blocker_rules.json; blocking is disabled", error)
        emptyList()
    }

    private fun JSONObject.stringList(key: String): List<String> =
        (optJSONArray(key) ?: JSONArray()).asStringList()

    private fun JSONArray.asStringList(): List<String> =
        List(length()) { index -> getString(index).trim().lowercase() }
            .filter(String::isNotBlank)

    private companion object {
        const val CONFIG_FILE = "blocker_rules.json"
        const val TAG = "DetoxBlockerConfig"
    }
}
