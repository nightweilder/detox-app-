package com.example.detox.blocker

data class ShortFormRule(
    val packageName: String,
    val viewIdTokens: List<String>,
    val textGroupsAnyOf: List<List<String>>
)
