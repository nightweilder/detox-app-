package com.example.detox.presentation.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.detox.domain.model.PermissionKind
import com.example.detox.presentation.emergency.EmergencySettingsEditor
import com.example.detox.presentation.reminder.ReminderPlanEditor

@Composable
fun OnboardingScreen(
    onOpenLibrary: () -> Unit = {},
    showSetup: Boolean = false,
    viewModel: OnboardingViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) viewModel.refresh() }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    if (state.isComplete && !showSetup) FocusedHome(onOpenLibrary)
    else PermissionSetup(
        statuses = state.statuses,
        isComplete = state.isComplete,
        onOpenSettings = { permission -> context.startActivity(viewModel.settingsIntent(permission)) },
        onFinish = viewModel::finishOnboarding,
        onOpenLibrary = onOpenLibrary
    )
}

@Composable
private fun FocusedHome(onOpenLibrary: () -> Unit) {
    val background = Brush.linearGradient(listOf(Color(0xFF101C19), Color(0xFF18352C), Color(0xFF25483B)))
    Box(Modifier.fillMaxSize().background(background)) {
        Box(Modifier.align(Alignment.TopEnd).padding(top = 82.dp, end = 28.dp).size(190.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0x2239C79A), Color.Transparent))))
        Box(Modifier.align(Alignment.BottomStart).padding(start = 4.dp, bottom = 58.dp).size(240.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0x1A82BFA1), Color.Transparent))))
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 34.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(Color(0xFFB8F28B)), contentAlignment = Alignment.Center) {
                    Text("d", color = Color(0xFF14231C), fontSize = 23.sp, fontWeight = FontWeight.Black)
                }
                Text("  DETOX", color = Color(0xFFEAF3E9), letterSpacing = 3.sp, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("A little less scroll.\nA little more story.", color = Color(0xFFF4F4E8), fontSize = 36.sp, lineHeight = 42.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                Text("Your next chapter is waiting.", color = Color(0xFFBED0C4), style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
                Spacer(Modifier.height(44.dp))
                Button(
                    onClick = onOpenLibrary,
                    modifier = Modifier.fillMaxWidth().height(76.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB8F28B), contentColor = Color(0xFF14231C)),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp, pressedElevation = 2.dp)
                ) {
                    Text("Open my library", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("   →", fontSize = 24.sp, fontWeight = FontWeight.Medium)
                }
                Spacer(Modifier.height(18.dp))
                Text("PICK UP A BOOK. FIND YOUR FLOW.", color = Color(0xFFB7C9BE), fontSize = 10.sp, letterSpacing = 2.sp, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(34.dp))
        }
    }
}

@Composable
private fun PermissionSetup(
    statuses: Map<PermissionKind, Boolean>,
    isComplete: Boolean,
    onOpenSettings: (PermissionKind) -> Unit,
    onFinish: () -> Unit,
    onOpenLibrary: () -> Unit
) {
    Surface(color = MaterialTheme.colorScheme.background) {
        androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxSize().padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Spacer(Modifier.height(36.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Detox setup", style = MaterialTheme.typography.headlineLarge)
                    OutlinedButton(onClick = onOpenLibrary) { Text("Library") }
                }
                Text("A few permissions help Detox stay ready.", style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(8.dp))
            }
            items(PermissionKind.entries.size) { index ->
                val permission = PermissionKind.entries[index]
                PermissionCard(permission, statuses[permission] == true) { onOpenSettings(permission) }
            }
            item { ReminderPlanEditor() }
            item { EmergencySettingsEditor() }
            item {
                if (isComplete) {
                    Text("Setup is complete. You can revisit these permissions any time.", style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = onFinish, modifier = Modifier.fillMaxWidth()) { Text("Refresh setup status") }
                } else Button(onClick = onFinish, modifier = Modifier.fillMaxWidth()) { Text("Finish setup") }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun PermissionCard(permission: PermissionKind, granted: Boolean, onOpenSettings: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(permission.title, style = MaterialTheme.typography.titleMedium)
                Text(permission.explanation, style = MaterialTheme.typography.bodySmall)
                Text(if (granted) "Enabled" else "Not enabled", style = MaterialTheme.typography.labelMedium)
            }
            OutlinedButton(onClick = onOpenSettings) { Text(if (granted) "Settings" else "Enable") }
        }
    }
}

