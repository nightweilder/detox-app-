package com.example.detox.presentation.reminder

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.detox.domain.model.ReminderPlan
import com.example.detox.domain.repository.ReminderPlanRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@HiltViewModel
class ReminderPlanViewModel @Inject constructor(
    private val repository: ReminderPlanRepository
) : ViewModel() {
    private val _plan = MutableStateFlow(ReminderPlan())
    val plan: StateFlow<ReminderPlan> = _plan.asStateFlow()

    init {
        viewModelScope.launch {
            repository.plan.collect { _plan.value = it }
        }
    }

    fun refresh() = viewModelScope.launch { _plan.value = repository.plan.first() }

    fun addGoal(value: String) = viewModelScope.launch { repository.addGoal(value) }
    fun removeGoal(value: String) = viewModelScope.launch { repository.removeGoal(value) }
    fun addTodo(value: String) = viewModelScope.launch { repository.addTodo(value) }
    fun removeTodo(value: String) = viewModelScope.launch { repository.removeTodo(value) }
}


