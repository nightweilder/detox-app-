package com.example.detox.data.repository

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.example.detox.domain.model.ReminderPlan
import com.example.detox.domain.repository.ReminderPlanRepository
import java.time.LocalDate
import javax.inject.Inject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ReminderPlanRepositoryImpl @Inject constructor(
    private val dataStore: DataStore<Preferences>
) : ReminderPlanRepository {
    private val goalsKey = stringPreferencesKey("reminder_goals")
    private val todosKey = stringPreferencesKey("reminder_todays_todos")
    private val todosDateKey = stringPreferencesKey("reminder_todos_date")

    override val plan: Flow<ReminderPlan> = dataStore.data.map { preferences ->
        val today = LocalDate.now().toString()
        val todaysTodos = if (preferences[todosDateKey] == today) {
            preferences[todosKey].toItems()
        } else {
            emptyList()
        }
        ReminderPlan(
            goals = preferences[goalsKey].toItems(),
            todaysTodos = todaysTodos
        )
    }

    override suspend fun addGoal(value: String) = addItem(goalsKey, value)
    override suspend fun removeGoal(value: String) = removeItem(goalsKey, value)

    override suspend fun addTodo(value: String) {
        val item = value.cleanItem()
        if (item.isBlank()) return
        val today = LocalDate.now().toString()
        dataStore.edit { preferences ->
            val current = if (preferences[todosDateKey] == today) preferences[todosKey].toItems() else emptyList()
            if (current.none { it.equals(item, ignoreCase = true) }) {
                preferences[todosKey] = (current + item).joinToString(NEWLINE)
            }
            preferences[todosDateKey] = today
        }
    }

    override suspend fun removeTodo(value: String) {
        val today = LocalDate.now().toString()
        dataStore.edit { preferences ->
            if (preferences[todosDateKey] == today) {
                preferences[todosKey] = preferences[todosKey].toItems().filterNot { it == value }.joinToString(NEWLINE)
            }
        }
    }

    private suspend fun addItem(key: Preferences.Key<String>, value: String) {
        val item = value.cleanItem()
        if (item.isBlank()) return
        dataStore.edit { preferences ->
            val current = preferences[key].toItems()
            if (current.none { it.equals(item, ignoreCase = true) }) {
                preferences[key] = (current + item).joinToString(NEWLINE)
            }
        }
    }

    private suspend fun removeItem(key: Preferences.Key<String>, value: String) {
        dataStore.edit { preferences ->
            preferences[key] = preferences[key].toItems().filterNot { it == value }.joinToString(NEWLINE)
        }
    }

    private fun String.cleanItem(): String = trim().replace(NEWLINE, " ")
    private fun String?.toItems(): List<String> =
        this.orEmpty().split(NEWLINE).map(String::trim).filter(String::isNotBlank)

    private companion object {
        const val NEWLINE = "\n"
    }
}
