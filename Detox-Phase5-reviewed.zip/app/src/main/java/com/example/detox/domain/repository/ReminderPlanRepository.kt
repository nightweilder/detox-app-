package com.example.detox.domain.repository

import com.example.detox.domain.model.ReminderPlan
import kotlinx.coroutines.flow.Flow

interface ReminderPlanRepository {
    val plan: Flow<ReminderPlan>
    suspend fun addGoal(value: String)
    suspend fun removeGoal(value: String)
    suspend fun addTodo(value: String)
    suspend fun removeTodo(value: String)
}
