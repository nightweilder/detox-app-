package com.example.detox.presentation.reminder

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding

import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

@Composable
fun ReminderPlanEditor(viewModel: ReminderPlanViewModel = hiltViewModel()) {
    val plan by viewModel.plan.collectAsStateWithLifecycle()
    var goalDraft by rememberSaveable { mutableStateOf("") }
    var todoDraft by rememberSaveable { mutableStateOf("") }
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) viewModel.refresh()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("YouTube intent reminder", style = MaterialTheme.typography.titleLarge)
            Text(
                "These goals and today's list appear when YouTube opens. Add or remove items whenever your plans change.",
                style = MaterialTheme.typography.bodyMedium
            )

            Text("My goals", style = MaterialTheme.typography.titleMedium)
            if (plan.goals.isEmpty()) Text("No goals added yet.", style = MaterialTheme.typography.bodySmall)
            plan.goals.forEach { goal ->
                EditablePlanRow(goal, onRemove = { viewModel.removeGoal(goal) })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = goalDraft,
                    onValueChange = { goalDraft = it },
                    modifier = Modifier.weight(1f),
                    label = { Text("Add a goal") },
                    singleLine = true
                )
                Button(
                    onClick = { viewModel.addGoal(goalDraft); goalDraft = "" },
                    enabled = goalDraft.isNotBlank()
                ) { Text("Add") }
            }

            Spacer(Modifier.height(4.dp))
            Text("Today's to-do list", style = MaterialTheme.typography.titleMedium)
            if (plan.todaysTodos.isEmpty()) Text("No tasks added yet.", style = MaterialTheme.typography.bodySmall)
            plan.todaysTodos.forEach { task ->
                EditablePlanRow(task, onRemove = { viewModel.removeTodo(task) })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = todoDraft,
                    onValueChange = { todoDraft = it },
                    modifier = Modifier.weight(1f),
                    label = { Text("Add a task for today") },
                    singleLine = true
                )
                Button(
                    onClick = { viewModel.addTodo(todoDraft); todoDraft = "" },
                    enabled = todoDraft.isNotBlank()
                ) { Text("Add") }
            }
        }
    }
}

@Composable
private fun EditablePlanRow(value: String, onRemove: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("• $value", modifier = Modifier.weight(1f).padding(top = 12.dp), style = MaterialTheme.typography.bodyMedium)
        TextButton(onClick = onRemove) { Text("Remove") }
    }
}



