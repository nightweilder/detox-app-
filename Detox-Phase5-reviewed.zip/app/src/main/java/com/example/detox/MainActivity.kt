package com.example.detox

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.DisposableEffect
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.detox.presentation.books.BookLibraryScreen
import com.example.detox.presentation.books.BookReaderScreen
import com.example.detox.presentation.onboarding.OnboardingScreen
import com.example.detox.presentation.theme.DetoxTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private var openLibrary: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val startAtLibrary = intent.getBooleanExtra(EXTRA_OPEN_LIBRARY, false)
        setContent {
            DetoxTheme {
                val nav = rememberNavController()
                DisposableEffect(nav) {
                    openLibrary = { nav.navigate("library") { launchSingleTop = true } }
                    onDispose { openLibrary = null }
                }
                NavHost(navController = nav, startDestination = if (startAtLibrary) "library" else "home") {
                    composable("home") { OnboardingScreen(onOpenLibrary = { nav.navigate("library") }) }
                    composable("library") { BookLibraryScreen(nav) }
                    composable("settings") { OnboardingScreen(showSetup = true, onOpenLibrary = { nav.popBackStack() }) }
                    composable("reader/{uri}") { entry -> BookReaderScreen(entry.arguments?.getString("uri").orEmpty(), nav) }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(EXTRA_OPEN_LIBRARY, false)) openLibrary?.invoke()
    }

    companion object { const val EXTRA_OPEN_LIBRARY = "com.example.detox.OPEN_LIBRARY" }
}
