package com.example.detox.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "emergency_judgments")
data class EmergencyJudgmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val requestText: String,
    val requestedAtEpochMillis: Long,
    val allowed: Boolean,
    val reason: String,
    val nightMode: Boolean,
    val unlockUntilEpochMillis: Long?
)
