package com.example.detox.presentation.emergency

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.time.format.DateTimeFormatter

@Composable
fun EmergencySettingsEditor(viewModel: EmergencySettingsViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var apiKeyDraft by remember { mutableStateOf("") }
    var startText by rememberSaveable { mutableStateOf(state.nightWindow.start.format(TIME_FORMAT)) }
    var endText by rememberSaveable { mutableStateOf(state.nightWindow.end.format(TIME_FORMAT)) }
    val lifecycleOwner = LocalLifecycleOwner.current

    LaunchedEffect(state.nightWindow) {
        startText = state.nightWindow.start.format(TIME_FORMAT)
        endText = state.nightWindow.end.format(TIME_FORMAT)
    }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) viewModel.refreshApiKeyStatus()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Emergency override settings", style = MaterialTheme.typography.titleLarge)
            Text(
                "The emergency reason you submit is sent to OpenAI for a decision. Requests and verdicts are logged locally in the app database.",
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                if (state.apiKeyAvailable) "OpenAI API key is saved on this device." else "OpenAI API key is not set.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedTextField(
                value = apiKeyDraft,
                onValueChange = { apiKeyDraft = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("OpenAI API key") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { viewModel.saveApiKey(apiKeyDraft); apiKeyDraft = "" }) {
                    Text("Save key")
                }
                OutlinedButton(onClick = viewModel::clearApiKey, enabled = state.apiKeyAvailable) {
                    Text("Remove key")
                }
            }
            Text("The key is encrypted at rest with Android Keystore and is never included in the APK source.", style = MaterialTheme.typography.bodySmall)

            Spacer(Modifier.height(4.dp))
            Text("Night mode", style = MaterialTheme.typography.titleMedium)
            Text(
                "Default 23:00–06:00 in your device’s local time. During these hours, only genuine family, safety, or work-critical urgency can be allowed.",
                style = MaterialTheme.typography.bodySmall
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = startText,
                    onValueChange = { startText = it },
                    modifier = Modifier.weight(1f),
                    label = { Text("Starts (HH:mm)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                    singleLine = true
                )
                OutlinedTextField(
                    value = endText,
                    onValueChange = { endText = it },
                    modifier = Modifier.weight(1f),
                    label = { Text("Ends (HH:mm)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                    singleLine = true
                )
            }
            Button(onClick = { viewModel.saveNightWindow(startText, endText) }) {
                Text("Save night hours")
            }
            state.message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

private val TIME_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")




