package com.example.detox.domain.ai

data class AiVerdict(
    val allow: Boolean,
    val reason: String
)

interface AiJudge {
    suspend fun judge(request: String, strictNightMode: Boolean): AiVerdict
}
