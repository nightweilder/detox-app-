package com.example.detox.data.repository

import com.example.detox.data.local.dao.BookDao
import com.example.detox.data.local.entity.BookEntity
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow

@Singleton
class BookRepository @Inject constructor(private val dao: BookDao) {
    val books: Flow<List<BookEntity>> = dao.observeBooks()
    suspend fun get(uri: String) = dao.get(uri)
    suspend fun add(book: BookEntity) = dao.put(book)
    suspend fun updateProgress(uri: String, index: Int, fraction: Float) = dao.updateProgress(uri, index, fraction)
    suspend fun fontSize(uri: String, size: Int) = dao.updateFontSize(uri, size)
    suspend fun theme(uri: String, theme: String) = dao.updateTheme(uri, theme)
    suspend fun remove(uri: String) = dao.delete(uri)
}
