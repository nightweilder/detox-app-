package com.example.detox.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import dagger.hilt.android.qualifiers.ApplicationContext
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AndroidKeystoreApiKeyStore @Inject constructor(
    @ApplicationContext context: Context
) : ApiKeyStore {
    private val preferences = context.getSharedPreferences(PREFERENCES_FILE, Context.MODE_PRIVATE)
    private val lock = Any()

    override fun saveApiKey(value: String) = synchronized(lock) {
        val keyValue = value.trim()
        if (keyValue.isEmpty()) {
            clearApiKey()
            return@synchronized
        }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(keyValue.toByteArray(Charsets.UTF_8))
        preferences.edit()
            .putString(CIPHERTEXT_KEY, Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .putString(IV_KEY, Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .apply()
    }

    override fun readApiKey(): String? = synchronized(lock) {
        val ciphertext = preferences.getString(CIPHERTEXT_KEY, null) ?: return@synchronized null
        val encodedIv = preferences.getString(IV_KEY, null) ?: return@synchronized null
        runCatching {
            val iv = Base64.decode(encodedIv, Base64.NO_WRAP)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(GCM_TAG_BITS, iv))
            String(cipher.doFinal(Base64.decode(ciphertext, Base64.NO_WRAP)), Charsets.UTF_8)
        }.getOrNull() // Do not wipe on failure: a transient Keystore error must not delete a valid key.
    }

    override fun hasApiKey(): Boolean = !readApiKey().isNullOrBlank()

    override fun clearApiKey() = synchronized(lock) {
        preferences.edit().remove(CIPHERTEXT_KEY).remove(IV_KEY).apply()
        runCatching {
            KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null); deleteEntry(KEY_ALIAS) }
        }
        Unit
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .setKeySize(KEY_SIZE_BITS)
                .build()
        )
        return generator.generateKey()
    }

    private companion object {
        const val ANDROID_KEYSTORE = "AndroidKeyStore"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val KEY_ALIAS = "detox_openai_api_key"
        const val PREFERENCES_FILE = "detox_secure_settings"
        const val CIPHERTEXT_KEY = "openai_api_key_ciphertext"
        const val IV_KEY = "openai_api_key_iv"
        const val GCM_TAG_BITS = 128
        const val KEY_SIZE_BITS = 256
    }
}

