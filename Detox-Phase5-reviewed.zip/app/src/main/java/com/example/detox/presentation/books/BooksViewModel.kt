package com.example.detox.presentation.books

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.detox.data.local.entity.BookEntity
import com.example.detox.data.repository.BookRepository
import com.example.detox.reader.EpubReader
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@HiltViewModel
class BooksViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: BookRepository
) : ViewModel() {
    val books = repository.books.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun import(uri: Uri, mimeType: String) = viewModelScope.launch {
        val title = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        } ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Untitled book"
        // Some pickers report application/octet-stream; fall back to the file name extension.
        val type = when {
            mimeType.contains("pdf", ignoreCase = true) -> "application/pdf"
            mimeType.contains("epub", ignoreCase = true) -> "application/epub+zip"
            title.endsWith(".pdf", ignoreCase = true) -> "application/pdf"
            else -> "application/epub+zip"
        }
        repository.add(BookEntity(uri.toString(), title, type))
    }

    fun remove(uri: String) = viewModelScope.launch { repository.remove(uri) }
    fun saveProgress(uri: String, index: Int, fraction: Float) = viewModelScope.launch { repository.updateProgress(uri, index, fraction) }
    fun setFont(uri: String, size: Int) = viewModelScope.launch { repository.fontSize(uri, size.coerceIn(12, 36)) }
    fun setTheme(uri: String, theme: String) = viewModelScope.launch { repository.theme(uri, theme) }

    suspend fun load(uri: String): BookEntity? = repository.get(uri)
    suspend fun epub(uri: String) = withContext(Dispatchers.IO) {
        EpubReader.read(context.contentResolver, Uri.parse(uri))
    }
}

