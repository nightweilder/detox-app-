package com.example.detox.domain.model

enum class PermissionKind(val title: String, val explanation: String) {
    ACCESSIBILITY("Accessibility", "Reads the visible interface in YouTube and Instagram on-device to detect Shorts or Reels and show the YouTube reminder. Screen content is not sent anywhere."),
    OVERLAY("Display over other apps", "Allows the blocker screen to appear above Shorts or Reels."),
    USAGE_ACCESS("Usage access", "Allows Detox to understand which app is currently in use for future reminder behavior."),
    BATTERY("Battery optimization", "Helps Android keep Detox available to detect short-form feeds in the background.")
}



